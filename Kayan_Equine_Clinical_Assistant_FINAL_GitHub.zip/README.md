# Kayan Equine Clinical Assistant — Final Edition v3

A mobile-first equine hospital and clinical decision-support web app.

## Included
- Login screen
- Hospital dashboard
- Horse registry: name, passport/microchip, stable, box, ownership, rider, alerts, photo
- Clinical cases with vitals, labs, imaging notes and case photos
- Structured modules: colic, lameness/hoof, respiratory, fever/infectious, wounds/trauma and eye
- Triage + differential diagnosis + recommended next steps
- 70+ condition quick-reference library
- Drug dose calculator
- Pharmacy stock + expiry tracking
- Treatment administration with automatic stock deduction
- Follow-up timeline
- Vaccination, deworming, dental, farriery and health-check records
- Printable/PDF clinical case reports
- Hospital/veterinarian/head-vet settings
- JSON backup/restore
- Arabic/English UI elements
- Kayan Athletic Future / KAPS:
  - Current fitness
  - Soundness
  - Health
  - Previous performance
  - Recovery
  - Training availability
  - Age/conformation suitability
  - Injury-risk index
  - Trend over repeated standardized tests
- PWA support for installation from GitHub Pages

## Default login
- Username: `admin`
- Password: `admin`

Change this from Settings before real deployment.

## Publish on GitHub Pages
1. Create a new public or private repository.
2. Upload **all files from this folder to the repository root**:
   - `index.html`
   - `manifest.webmanifest`
   - `service-worker.js`
3. Commit the files.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch `main` and folder `/ (root)`.
7. Save.
8. GitHub will provide the app URL. Open it on Android Chrome and choose **Add to Home screen / Install app**.

## Important clinical note
KAPS and the diagnostic scoring rules are internal decision-support heuristics, not externally validated predictive medical devices. They should be calibrated against standardized exercise tests, hospital SOPs, competition data, imaging findings and veterinary judgment before operational use.

Data are currently stored locally in the browser (LocalStorage). Clearing browser/site data can remove records, so use the built-in JSON backup routinely.
