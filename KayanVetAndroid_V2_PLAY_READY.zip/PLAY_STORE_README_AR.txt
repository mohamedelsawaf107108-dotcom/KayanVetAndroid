Kayan Vet Hospital V2 — نسخة Android المجهزة للنشر

• شاشة الدخول الجديدة صفحة واحدة بهوية Kayan Club ورقم 01017284646.
• لا توجد موسيقى داخل التطبيق.
• Target/Compile SDK = 36 (Android 16).
• GitHub Actions يبني APK تجريبي.
• بناء AAB النهائي يحتاج مفتاح Upload ثابت عبر GitHub Secrets ولا يجب نشر المفتاح داخل الريبو.
• النشر العام نفسه يحتاج Google Play Console ومراجعة المتجر.
