KAYAN VET HOSPITAL - Android Project
====================================

المشروع مبني ليحوّل منظومة Kayan Vet إلى تطبيق Android مستقل.

المميزات:
- أيقونة مستقلة بشعار KAYAN CLUB.
- Splash Screen احترافية بالشعار.
- يعمل Offline لأن ملف المنظومة داخل التطبيق.
- حفظ بيانات المنظومة داخل WebView Local Storage.
- اختيار صور الخيل والباسبور من ملفات/صور الهاتف.
- تصدير Backup و CSV إلى Downloads/KayanVet على Android 10 فأحدث.
- واجهة Responsive محسنة للموبايل.

طريقة إخراج APK:
1) افتح مجلد KayanVetAndroid في Android Studio.
2) انتظر Gradle Sync وتحميل Android SDK 35 إن طلبه البرنامج.
3) من Build اختر Build APK(s).
4) ستجد الملف في app/build/outputs/apk/debug/app-debug.apk

Package: com.kayan.vethospital
App name: Kayan Vet Hospital
Min Android: Android 6.0 (API 23)
Target: Android 15 (API 35)


تحديث الصورة: تم استخدام الصورة الجديدة المرسلة كأيقونة التطبيق وشاشة البداية.

=== نسخة AndroidIDE Mobile Build Compatible ===
تمت إضافة gradlew المطلوب بواسطة AndroidIDE.
تم ضبط Android Gradle Plugin إلى 8.2.2 و compile/target SDK إلى 34 لزيادة التوافق على الموبايل.
افتح مجلد KayanVetAndroid نفسه ثم اضغط Run.
