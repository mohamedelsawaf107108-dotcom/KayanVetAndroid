# Kayan Equine Clinical Assistant — Android APK

This is a complete Android wrapper for the Kayan Equine Clinical Assistant web application.

## What it includes
- Full Kayan Equine Clinical Assistant v3 inside the APK
- Works offline because index.html is bundled in Android assets
- LocalStorage / horse records / cases / pharmacy / KAPS data
- Image and file chooser support
- Android back-button handling
- Android printing for clinical reports
- GitHub Actions workflow that automatically builds an installable APK

## Default login
Username: admin
Password: admin

Change it from Settings.

## Build APK on GitHub
Upload the entire project folder contents to the ROOT of your GitHub repository.

Important files/folders:
- app/
- .github/workflows/build-apk.yml
- build.gradle
- settings.gradle
- gradle.properties

Then:
1. Open GitHub repository.
2. Open Actions.
3. Choose "Build Kayan Equine Android APK".
4. Tap "Run workflow".
5. Wait for the green check.
6. Open the completed run.
7. Under Artifacts download:
   Kayan-Equine-Clinical-Assistant-APK
8. Unzip the downloaded artifact.
9. Install Kayan-Equine-Clinical-Assistant.apk on Android.

Android may ask you to allow "Install unknown apps" for your browser/file manager.

## Notes
The GitHub Action builds a DEBUG APK. It is installable and is ideal for internal testing.
For Play Store or formal distribution, create a signed RELEASE APK/AAB with a private keystore.

Clinical note: KAPS and diagnosis/triage scoring are decision-support heuristics and must not be used as the sole basis for diagnosis, treatment, purchase/sale, competition clearance, or prognosis.
