# Kayan Equine Clinical Assistant
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
