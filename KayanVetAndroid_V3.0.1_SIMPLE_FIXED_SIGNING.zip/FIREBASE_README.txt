Kayan Vet Hospital V2.2 - Firebase Sync

- Firebase project: kayan-vet-hospital
- Android package: com.kayan.vethospital
- google-services.json included in app/
- Firestore synchronization included for medicines, feed, horses, cases, and moves.
- Local storage remains as offline/fallback cache.
- Back button handling and logout are included.

IMPORTANT: Firestore Security Rules must permit the app to read/write. FIRESTORE_RULES_TEST_ONLY.txt is only for a short private test. Do not use open rules for a public/commercial release.
