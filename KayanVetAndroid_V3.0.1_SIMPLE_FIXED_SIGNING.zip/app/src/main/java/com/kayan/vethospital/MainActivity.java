package com.kayan.vethospital;

import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;
import android.graphics.Bitmap;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Gravity;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.WriteBatch;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 4001;
    private static final String[] CLOUD_COLLECTIONS = {"medicines", "feed", "horses", "cases", "moves"};
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private FrameLayout splash;
    private FirebaseFirestore firestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        firestore = FirebaseFirestore.getInstance();
        buildUi();
        configureWebView();
        webView.loadUrl("file:///android_asset/index.html");
        webView.postDelayed(() -> handleDeepLink(getIntent()), 1000);
        setupDailyRestHorsesNotification();
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        splash = new FrameLayout(this);
        splash.setBackgroundColor(Color.rgb(6, 59, 73));
        ImageView logo = new ImageView(this);
        logo.setImageResource(com.kayan.vethospital.R.drawable.kayan_splash);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        FrameLayout.LayoutParams logoLp = new FrameLayout.LayoutParams(dp(290), dp(290));
        logoLp.gravity = Gravity.CENTER; logoLp.bottomMargin = dp(42); splash.addView(logo, logoLp);
        TextView title = new TextView(this);
        title.setText("KAYAN VET HOSPITAL"); title.setTextColor(Color.rgb(198, 168, 91)); title.setTextSize(18f); title.setGravity(Gravity.CENTER); title.setLetterSpacing(0.10f);
        FrameLayout.LayoutParams titleLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60));
        titleLp.gravity = Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM; titleLp.bottomMargin = dp(90); splash.addView(title, titleLp);
        TextView sub = new TextView(this);
        sub.setText("مستشفى نادي كيان للفروسية"); sub.setTextColor(Color.WHITE); sub.setTextSize(16f); sub.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams subLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        subLp.gravity = Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM; subLp.bottomMargin = dp(48); splash.addView(sub, subLp);
        root.addView(splash, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false); s.setSupportZoom(false); s.setMediaPlaybackRequiresUserGesture(false); s.setJavaScriptCanOpenWindowsAutomatically(true); s.setSupportMultipleWindows(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) { s.setAllowFileAccessFromFileURLs(true); s.setAllowUniversalAccessFromFileURLs(false); }
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (splash != null) splash.animate().alpha(0f).setDuration(350).withEndAction(() -> splash.setVisibility(View.GONE)).start();
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null); filePathCallback = cb;
                try { startActivityForResult(params.createIntent(), FILE_CHOOSER_REQUEST); return true; }
                catch (Exception e) { filePathCallback = null; return false; }
            }
        });
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) { filePathCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data)); filePathCallback = null; }
    }

    @Override public void onBackPressed() {
        if (webView == null) { super.onBackPressed(); return; }
        webView.evaluateJavascript("(typeof KayanHandleAndroidBack==='function'?KayanHandleAndroidBack():'exit')", value -> {
            if (value != null && value.contains("exit")) MainActivity.super.onBackPressed();
        });
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    public class AndroidBridge {
        @JavascriptInterface public void saveText(String filename, String content, String mimeType) { runOnUiThread(() -> saveToDownloads(filename, content, mimeType)); }
        
        @JavascriptInterface
        public String generateQr(String text) {
            try {
                BitMatrix matrix = new MultiFormatWriter().encode(text, BarcodeFormat.QR_CODE, 700, 700);
                Bitmap bmp = Bitmap.createBitmap(700, 700, Bitmap.Config.RGB_565);
                for (int x = 0; x < 700; x++)
                    for (int y = 0; y < 700; y++)
                        bmp.setPixel(x, y, matrix.get(x, y) ? 0xFF000000 : 0xFFFFFFFF);
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.PNG, 100, out);
                return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
            } catch (Exception e) { return ""; }
        }

@JavascriptInterface public void loadCloudData() { runOnUiThread(() -> readAllCloudData()); }
        @JavascriptInterface public void syncData(String json) { runOnUiThread(() -> syncAllCloudData(json)); }
        @JavascriptInterface public void loadBundledBackup() { runOnUiThread(() -> readBundledBackup()); }
    
        @JavascriptInterface
        public void exportBackup(String json, String fileName) {
            runOnUiThread(() -> {
                try {
                    String safeName = (fileName == null || fileName.trim().isEmpty())
                            ? "Kayan_Vet_FULL_Backup.json" : fileName.trim();
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                        values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/KayanVet");
                    }
                    android.net.Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("تعذر إنشاء الملف");
                    try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                        if (os == null) throw new Exception("تعذر فتح الملف");
                        os.write(json.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                        os.flush();
                    }
                    webView.evaluateJavascript("KayanBackupExported(" + org.json.JSONObject.quote("Downloads/KayanVet/" + safeName) + ")", null);
                } catch (Exception e) {
                    webView.evaluateJavascript("KayanBackupExportError(" + org.json.JSONObject.quote(e.getMessage()) + ")", null);
                }
            });
        }

}


    private void readBundledBackup() {
        try (InputStream is = getAssets().open("computer_backup.json");
             ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int n;
            while ((n = is.read(buffer)) != -1) bos.write(buffer, 0, n);
            String json = bos.toString(StandardCharsets.UTF_8.name());
            jsCall("KayanBundledBackupLoaded", json);
        } catch (Exception e) {
            jsCall("KayanBundledBackupError", e.getMessage());
        }
    }

    private void readAllCloudData() {
        Map<String, JSONArray> all = new HashMap<>();
        AtomicInteger remaining = new AtomicInteger(CLOUD_COLLECTIONS.length);
        final boolean[] failed = {false};
        for (String name : CLOUD_COLLECTIONS) {
            firestore.collection(name).get().addOnSuccessListener(q -> {
                JSONArray arr = new JSONArray();
                for (DocumentSnapshot d : q.getDocuments()) arr.put(new JSONObject(d.getData()));
                all.put(name, arr);
                if (remaining.decrementAndGet() == 0 && !failed[0]) finishCloudRead(all);
            }).addOnFailureListener(e -> {
                if (!failed[0]) { failed[0] = true; jsCall("KayanCloudError", e.getMessage()); }
            });
        }
    }

    private void finishCloudRead(Map<String, JSONArray> all) {
        int count = 0; for (JSONArray a : all.values()) count += a.length();
        if (count == 0) { jsEval("KayanCloudEmpty()"); return; }
        JSONObject root = new JSONObject();
        try { for (String name : CLOUD_COLLECTIONS) root.put(name, all.containsKey(name) ? all.get(name) : new JSONArray()); }
        catch (JSONException ignored) {}
        jsCall("KayanCloudLoaded", root.toString());
    }

    private void syncAllCloudData(String json) {
        try {
            JSONObject root = new JSONObject(json);
            AtomicInteger remaining = new AtomicInteger(CLOUD_COLLECTIONS.length);
            final boolean[] failed = {false};
            for (String name : CLOUD_COLLECTIONS) {
                JSONArray arr = root.optJSONArray(name); if (arr == null) arr = new JSONArray();
                syncCollection(name, arr, () -> {
                    if (remaining.decrementAndGet() == 0 && !failed[0]) jsEval("KayanCloudSaved()");
                }, err -> {
                    if (!failed[0]) { failed[0] = true; jsCall("KayanCloudError", err); }
                });
            }
        } catch (Exception e) { jsCall("KayanCloudError", e.getMessage()); }
    }

    private interface Done { void run(); }
    private interface Fail { void run(String msg); }

    private void syncCollection(String name, JSONArray arr, Done done, Fail fail) {
        final JSONArray data = arr;
        firestore.collection(name).get().addOnSuccessListener(existing -> {
            try {
                WriteBatch batch = firestore.batch();
                Map<String, Boolean> wanted = new HashMap<>();
                for (int i = 0; i < data.length(); i++) {
                    JSONObject o = data.getJSONObject(i);
                    String id = o.optString("id", name + "_" + i);
                    wanted.put(id, true);
                    batch.set(firestore.collection(name).document(id), jsonObjectToMap(o));
                }
                for (DocumentSnapshot d : existing.getDocuments()) if (!wanted.containsKey(d.getId())) batch.delete(d.getReference());
                batch.commit().addOnSuccessListener(v -> done.run()).addOnFailureListener(e -> fail.run(e.getMessage()));
            } catch (Exception e) { fail.run(e.getMessage()); }
        }).addOnFailureListener(e -> fail.run(e.getMessage()));
    }

    private Map<String, Object> jsonObjectToMap(JSONObject object) throws JSONException {
        Map<String, Object> map = new HashMap<>();
        Iterator<String> keys = object.keys();
        while (keys.hasNext()) { String key = keys.next(); map.put(key, jsonToJava(object.get(key))); }
        return map;
    }

    private Object jsonToJava(Object value) throws JSONException {
        if (value == JSONObject.NULL) return null;
        if (value instanceof JSONObject) return jsonObjectToMap((JSONObject) value);
        if (value instanceof JSONArray) {
            JSONArray a = (JSONArray) value; List<Object> list = new ArrayList<>();
            for (int i = 0; i < a.length(); i++) list.add(jsonToJava(a.get(i)));
            return list;
        }
        return value;
    }

    private void jsCall(String function, String text) {
        String quoted = JSONObject.quote(text == null ? "" : text);
        jsEval(function + "(" + quoted + ")");
    }
    private void jsEval(String code) { runOnUiThread(() -> webView.evaluateJavascript(code, null)); }

    private void saveToDownloads(String filename, String content, String mimeType) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return;
        try {
            ContentValues values = new ContentValues(); values.put(MediaStore.Downloads.DISPLAY_NAME, filename); values.put(MediaStore.Downloads.MIME_TYPE, mimeType == null || mimeType.isEmpty() ? "text/plain" : mimeType); values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/KayanVet");
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values); if (uri == null) return;
            try (OutputStream os = getContentResolver().openOutputStream(uri)) { if (os != null) os.write(content.getBytes(StandardCharsets.UTF_8)); }
        } catch (Exception ignored) { }
    }

    @Override
    protected void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent); setIntent(intent); handleDeepLink(intent);
    }
    private void handleDeepLink(android.content.Intent intent) {
        if (intent == null || intent.getData() == null || webView == null) return;
        String url = intent.getData().toString().replace("\\", "\\\\").replace("'", "\\'");
        webView.postDelayed(() -> webView.evaluateJavascript(
            "typeof openHorseFromDeepLink==='function' && openHorseFromDeepLink('" + url + "')", null), 600);
    }


    private void setupDailyRestHorsesNotification() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                new String[]{Manifest.permission.POST_NOTIFICATIONS},
                2808
            );
        }

        Calendar now = Calendar.getInstance();
        Calendar next = Calendar.getInstance();
        next.set(Calendar.HOUR_OF_DAY, 8);
        next.set(Calendar.MINUTE, 0);
        next.set(Calendar.SECOND, 0);
        next.set(Calendar.MILLISECOND, 0);
        if (!next.after(now)) next.add(Calendar.DAY_OF_MONTH, 1);

        long initialDelay = next.getTimeInMillis() - now.getTimeInMillis();

        PeriodicWorkRequest request =
            new PeriodicWorkRequest.Builder(RestHorsesWorker.class, 24, TimeUnit.HOURS)
                .setInitialDelay(initialDelay, TimeUnit.MILLISECONDS)
                .build();

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "daily_rest_horses",
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        );
    }

}
