package com.kayan.vethospital;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class RestHorsesWorker extends Worker {
    private static final String CHANNEL_ID = "rest_horses_daily";

    public RestHorsesWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        List<String> names = new ArrayList<>();
        CountDownLatch latch = new CountDownLatch(1);

        FirebaseFirestore.getInstance()
            .collection("horses")
            .whereEqualTo("workStatus", "rest")
            .get()
            .addOnSuccessListener(snapshot -> {
                for (QueryDocumentSnapshot doc : snapshot) {
                    String name = doc.getString("name");
                    if (name == null || name.trim().isEmpty()) name = "حصان بدون اسم";
                    String stable = doc.getString("stable");
                    String box = doc.getString("box");

                    StringBuilder line = new StringBuilder(name);
                    if (stable != null && !stable.trim().isEmpty()) line.append(" - ").append(stable);
                    if (box != null && !box.trim().isEmpty()) line.append(" / بوكس ").append(box);
                    names.add(line.toString());
                }
                latch.countDown();
            })
            .addOnFailureListener(e -> latch.countDown());

        try {
            latch.await(20, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {}

        if (!names.isEmpty()) showNotification(names);
        return Result.success();
    }

    private void showNotification(List<String> names) {
        Context context = getApplicationContext();
        NotificationManager nm =
            (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "الخيل في الراحة",
                NotificationManager.IMPORTANCE_DEFAULT
            );
            channel.setDescription("تنبيه يومي بالخيل الموجودة في الراحة");
            nm.createNotificationChannel(channel);
        }

        String title = "🛌 الخيل في الراحة اليوم: " + names.size();
        StringBuilder body = new StringBuilder();
        for (int i = 0; i < Math.min(names.size(), 8); i++) {
            if (i > 0) body.append(" • ");
            body.append(names.get(i));
        }
        if (names.size() > 8) {
            body.append(" • +").append(names.size() - 8).append(" أخرى");
        }

        NotificationCompat.Builder builder =
            new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(body.toString())
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body.toString()))
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        nm.notify(2808, builder.build());
    }
}
