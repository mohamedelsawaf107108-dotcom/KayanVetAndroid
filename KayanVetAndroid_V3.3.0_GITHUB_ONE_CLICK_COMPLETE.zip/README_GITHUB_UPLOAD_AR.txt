Kayan Vet Hospital V3.3.0 - GitHub One Click Build

1) أنشئ Repository جديد على GitHub ويفضل Private.
2) فك ضغط هذا الملف على الهاتف/الكمبيوتر.
3) ارفع محتويات المجلد نفسها إلى جذر الـRepository، وليس ملف ZIP فقط.
4) يجب أن ترى في الصفحة الرئيسية: app / gradle / .github / build.gradle / settings.gradle
5) ملف Workflow موجود بالفعل في: .github/workflows/main.yml
6) افتح Actions ثم Build Kayan Vet V3.3.0 APK ثم Run workflow.
7) بعد نجاح البناء افتح Run ثم Artifacts وحمّل Kayan-Vet-Hospital-V3.3.0.
8) داخل الـArtifact ستجد Kayan-Vet-Hospital-V3.3.0.apk وهو Debug APK موقّع تلقائيًا وقابل للتثبيت.

لا تحتاج GitHub Secrets ولا keystore لهذه النسخة.
