My Life V2.5
- Premium home now shows a clear compact 60/30 Focus Cycle card.
- 60 min focus / 30 min break timer visible from home with live countdown.
- Start/pause directly from home; full timer opens with one tap.
- All five life pillars remain visible.
- Same permanent package/signing key.
