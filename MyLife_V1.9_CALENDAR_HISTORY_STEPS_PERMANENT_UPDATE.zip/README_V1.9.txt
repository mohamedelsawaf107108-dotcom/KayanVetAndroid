My Life V1.9.0 (versionCode 10)
Package: com.mylife.app
Signing: same permanent app/mylife-release.jks

New:
1) Calendar keeps and displays ALL saved entries, including past dates and future dates, in "كل المحفوظ — قديم وجديد".
2) New phone step counter using Android TYPE_STEP_COUNTER + ACTIVITY_RECOGNITION permission.
3) Calculates estimated distance from height and estimated walking calories from weight.
4) Shows an approximate food equivalent for burned calories.
5) Weight and height are editable inside Activity/Steps page.
6) Keeps V1.8 robust Adhkar fix.
