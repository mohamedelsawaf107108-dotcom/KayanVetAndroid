# KAYAN Equestrian Command — Android

Open this `android` directory in Android Studio, allow Gradle sync to complete, then use
**Build > Generate Signed Bundle / APK > APK**. The application ID is
`com.kayan.equestriancommand` and the production web platform remains the single source of data.
