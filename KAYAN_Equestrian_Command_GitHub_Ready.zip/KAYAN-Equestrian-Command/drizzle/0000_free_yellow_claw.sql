CREATE TABLE `clinical_cases` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`horse_name` text NOT NULL,
	`stable` text NOT NULL,
	`diagnosis` text NOT NULL,
	`priority` text DEFAULT 'Routine' NOT NULL,
	`treatment` text DEFAULT '' NOT NULL,
	`doctor` text DEFAULT 'Veterinary Team' NOT NULL,
	`status` text DEFAULT 'Open' NOT NULL,
	`event_date` text NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE TABLE `horses` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`name` text NOT NULL,
	`stable` text NOT NULL,
	`breed` text DEFAULT '' NOT NULL,
	`sex` text DEFAULT '' NOT NULL,
	`ownership` text DEFAULT 'Official' NOT NULL,
	`status` text DEFAULT 'Active' NOT NULL,
	`passport_number` text,
	`notes` text DEFAULT '' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE TABLE `inventory_items` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`name` text NOT NULL,
	`sector` text NOT NULL,
	`category` text DEFAULT 'General' NOT NULL,
	`unit` text DEFAULT 'unit' NOT NULL,
	`balance` real DEFAULT 0 NOT NULL,
	`reorder_level` real DEFAULT 0 NOT NULL,
	`expiry_date` text,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE TABLE `stock_transactions` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`item_id` integer,
	`sector` text NOT NULL,
	`direction` text NOT NULL,
	`quantity` real NOT NULL,
	`reference` text DEFAULT '' NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
