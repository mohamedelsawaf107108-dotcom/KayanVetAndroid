# رفع تطبيق KAYAN على GitHub وبناء APK

## 1. إنشاء المستودع

1. افتح https://github.com/new
2. اكتب اسم المستودع: `kayan-equestrian-command`
3. اختر **Private** لحماية الكود والبيانات.
4. لا تضف README أو .gitignore من GitHub.
5. اضغط **Create repository**.

## 2. رفع الملفات من الموبايل أو الكمبيوتر

فك ضغط الملف، ثم ارفع جميع محتوياته إلى المستودع مع الحفاظ على المجلدات.
يمكن استخدام **Add file > Upload files**، أو GitHub Desktop على الكمبيوتر.

## 3. إنشاء ملف APK تلقائيًا

1. افتح تبويب **Actions** داخل المستودع.
2. اختر **Build Android APK**.
3. اضغط **Run workflow** ثم **Run workflow** مرة أخرى.
4. انتظر حتى تظهر علامة النجاح الخضراء.
5. افتح نتيجة التشغيل وانزل إلى **Artifacts**.
6. نزّل `KAYAN-Equestrian-Command-APK` وفك الضغط.
7. ثبّت `app-debug.apk` على جهاز Android.

## ملاحظات مهمة

- التطبيق يتصل بالنسخة السحابية: https://kayan-equestrian-command.wintry-degu-1733.chatgpt.site
- مشاهدة الواجهة متاحة، لكن تعديل السجلات يتطلب تسجيل الدخول.
- ملف Debug مناسب للتجربة الداخلية. النشر على Google Play يحتاج توقيع Release خاص بك.
- لا ترفع كلمات المرور أو مفاتيح التوقيع إلى GitHub.

