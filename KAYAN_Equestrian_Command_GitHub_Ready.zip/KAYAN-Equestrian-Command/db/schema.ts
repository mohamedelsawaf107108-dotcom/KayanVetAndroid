import { sql } from "drizzle-orm";
import { integer, real, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const horses = sqliteTable("horses", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(), stable: text("stable").notNull(), breed: text("breed").notNull().default(""),
  sex: text("sex").notNull().default(""), ownership: text("ownership").notNull().default("Official"),
  status: text("status").notNull().default("Active"), passportNumber: text("passport_number"),
  notes: text("notes").notNull().default(""), createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});
export const inventoryItems = sqliteTable("inventory_items", {
  id: integer("id").primaryKey({ autoIncrement: true }), name: text("name").notNull(),
  sector: text("sector").notNull(), category: text("category").notNull().default("General"),
  unit: text("unit").notNull().default("unit"), balance: real("balance").notNull().default(0),
  reorderLevel: real("reorder_level").notNull().default(0), expiryDate: text("expiry_date"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});
export const stockTransactions = sqliteTable("stock_transactions", {
  id: integer("id").primaryKey({ autoIncrement: true }), itemId: integer("item_id"),
  sector: text("sector").notNull(), direction: text("direction").notNull(), quantity: real("quantity").notNull(),
  reference: text("reference").notNull().default(""), notes: text("notes").notNull().default(""),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});
export const clinicalCases = sqliteTable("clinical_cases", {
  id: integer("id").primaryKey({ autoIncrement: true }), horseName: text("horse_name").notNull(),
  stable: text("stable").notNull(), diagnosis: text("diagnosis").notNull(), priority: text("priority").notNull().default("Routine"),
  treatment: text("treatment").notNull().default(""), doctor: text("doctor").notNull().default("Veterinary Team"),
  status: text("status").notNull().default("Open"), eventDate: text("event_date").notNull(),
  notes: text("notes").notNull().default(""), createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});
