import { desc } from "drizzle-orm";
import { getDb } from "../../../db";
import { clinicalCases, horses, stockTransactions } from "../../../db/schema";

export async function GET() {
  try {
    const db = getDb();
    const [horseRows, caseRows, transactionRows] = await Promise.all([
      db.select().from(horses).orderBy(desc(horses.id)).limit(50),
      db.select().from(clinicalCases).orderBy(desc(clinicalCases.id)).limit(50),
      db.select().from(stockTransactions).orderBy(desc(stockTransactions.id)).limit(100),
    ]);
    return Response.json({ horses: horseRows, cases: caseRows, transactions: transactionRows });
  } catch (error) { return Response.json({ error: error instanceof Error ? error.message : "Database unavailable" }, { status: 500 }); }
}

export async function POST(request: Request) {
  try {
    const userId = request.headers.get("oai-authenticated-user-id");
    if (!userId) {
      return Response.json(
        { error: "Sign in with ChatGPT to modify command records" },
        { status: 401 },
      );
    }
    const body = await request.json() as Record<string, string | number>;
    const kind = String(body.kind ?? ""); const db = getDb();
    if (kind === "horse") {
      const name = String(body.name ?? "").trim(); if (!name) return Response.json({error:"Horse name is required"},{status:400});
      const [record] = await db.insert(horses).values({ name, stable:String(body.sector??"Stable 1"), breed:String(body.category??""), notes:String(body.notes??"") }).returning();
      return Response.json({ record }, { status: 201 });
    }
    if (kind === "case") {
      const horseName=String(body.name??"").trim(); if(!horseName) return Response.json({error:"Horse name is required"},{status:400});
      const [record]=await db.insert(clinicalCases).values({horseName,stable:String(body.sector??"Stable 1"),diagnosis:String(body.category??"Clinical assessment"),priority:String(body.priority??"Routine"),eventDate:String(body.date??new Date().toISOString().slice(0,10)),notes:String(body.notes??"")}).returning();
      return Response.json({record},{status:201});
    }
    if (kind === "stock") {
      const [record]=await db.insert(stockTransactions).values({sector:String(body.sector??"Pharmacy"),direction:String(body.direction??"IN"),quantity:Number(body.quantity??1),reference:String(body.name??"Stock transaction"),notes:String(body.notes??"")}).returning();
      return Response.json({record},{status:201});
    }
    return Response.json({error:"Unsupported record type"},{status:400});
  } catch (error) { return Response.json({ error: error instanceof Error ? error.message : "Unable to save record" }, { status: 500 }); }
}
