import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "KAYAN: Equestrian Command",
  description: "Integrated equestrian veterinary hospital command and operations platform.",
  manifest: "/manifest.webmanifest",
  applicationName: "KAYAN Command",
  appleWebApp: { capable: true, title: "KAYAN Command", statusBarStyle: "black-translucent" },
  themeColor: "#071b19",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body className="antialiased">{children}</body>
    </html>
  );
}
