# KAYAN Equestrian Command

Premium equestrian-club operations platform with interactive campus visualization,
horse registry, veterinary cases, pharmacy stock and feed management.

## Included

- English responsive web application and installable PWA
- Interactive 3D campus and cinematic command view
- Leadership opening experience
- Cloud-backed operational records
- Android wrapper project in `android/`
- Automatic APK build with GitHub Actions

Arabic setup instructions: [GITHUB_SETUP_AR.md](GITHUB_SETUP_AR.md)

Live application: https://kayan-equestrian-command.wintry-degu-1733.chatgpt.site
