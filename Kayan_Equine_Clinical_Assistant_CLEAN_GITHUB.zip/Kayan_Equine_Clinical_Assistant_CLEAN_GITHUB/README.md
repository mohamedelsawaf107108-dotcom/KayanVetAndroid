# Kayan Equine Clinical Assistant

Clean Android project ready for GitHub Actions.

## Build APK
1. Upload the CONTENTS of this folder to the root of a new GitHub repository (do not upload the ZIP as a single file).
2. Open Actions.
3. Select **Build Kayan Equine Android APK** (or Build Kayan Equine APK) and run it.
4. When the run is green, open it and download the artifact **Kayan-Equine-Clinical-Assistant-FINAL-APK**.
5. Extract the downloaded artifact and install `Kayan-Equine-Clinical-Assistant-FINAL.apk` on Android.

App id: `com.kayan.equine`
Minimum Android: 7.0 (API 24)
Target/compile SDK: 35
Java: 17
Gradle: 8.9
