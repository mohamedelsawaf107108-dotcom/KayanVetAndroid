# My Life V1

Arabic-first Android life operating system built around five pillars:
- Spiritual
- Health
- Personal
- Professional
- Financial

## Core features
- Add, edit, pause, complete, and delete goals from inside each pillar.
- Daily/weekly/monthly/one-time goals.
- XP, levels, streaks, rewards, celebration animations, and animated mountain progress scene.
- Daily dashboard, calendar, statistics, five-pillar balance, rewards.
- Local offline storage.
- JSON backup export/import.
- Android WebView wrapper; no server or Firebase required for V1.

## Build
Open the repository in Android Studio, or run the included GitHub Actions workflow.

Application ID: `com.mylife.app`
Version: `1.0.0`

## V1.1 — Focus Cycle 60/30
- Timer افتراضي: 60 دقيقة تركيز + 30 دقيقة راحة.
- ينتقل تلقائياً بين التركيز والراحة على مدار اليوم.
- اختيار الهدف الحالي من أهداف My Life.
- Pause / Resume / Skip / Reset.
- إحصاء دورات التركيز والراحة ودقائق التركيز اليومية.
- +10 XP لكل ساعة تركيز مكتملة.
- يحفظ حالة التايمر محلياً، ويستمر حساب الوقت بعد التنقل داخل التطبيق.
- يمنع الشاشة من النوم أثناء تشغيل التايمر داخل تطبيق Android.
