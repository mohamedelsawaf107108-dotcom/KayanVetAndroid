My Life V1.6
- package/applicationId remains com.mylife.app
- uses the same permanent release keystore already introduced in V1.4/V1.5
- visible quick access to Adhkar, Quran and Calendar from Home
- expanded morning/evening adhkar
- Calendar planner: weekly, monthly, yearly recurring events + reminders
- versionCode 7 / versionName 1.6.0
IMPORTANT: an app currently installed with an older DEBUG signature cannot be updated by a release-signed APK. Export backup, uninstall once, install V1.6, then future permanent-signed updates can install over it.
