package com.mylife.app;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Calendar;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String id = intent.getStringExtra("id");
        String title = intent.getStringExtra("title");
        String repeat = intent.getStringExtra("repeat");
        long at = intent.getLongExtra("atMillis", System.currentTimeMillis());
        Intent launch = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        PendingIntent content = PendingIntent.getActivity(context, id == null ? 0 : id.hashCode(), launch, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = new Notification.Builder(context, "mylife_reminders")
                .setSmallIcon(com.mylife.app.R.mipmap.ic_launcher)
                .setContentTitle("My Life • تذكير")
                .setContentText(title == null ? "لديك هدف أو موعد الآن" : title)
                .setAutoCancel(true)
                .setContentIntent(content);
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(id == null ? 1 : id.hashCode(), b.build());
        if (repeat != null && !"none".equals(repeat) && id != null) {
            Calendar c = Calendar.getInstance(); c.setTimeInMillis(at);
            if ("weekly".equals(repeat)) c.add(Calendar.WEEK_OF_YEAR,1);
            else if ("monthly".equals(repeat)) c.add(Calendar.MONTH,1);
            else if ("yearly".equals(repeat)) c.add(Calendar.YEAR,1);
            Intent next = new Intent(context, ReminderReceiver.class);
            next.putExtra("id", id); next.putExtra("title", title); next.putExtra("repeat", repeat); next.putExtra("atMillis", c.getTimeInMillis());
            PendingIntent pi = PendingIntent.getBroadcast(context, id.hashCode(), next, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
            if(am!=null) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),pi);
        }
    }
}
