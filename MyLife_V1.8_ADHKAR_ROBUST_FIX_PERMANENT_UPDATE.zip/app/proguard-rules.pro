# My Life V1 - no custom ProGuard rules yet.
