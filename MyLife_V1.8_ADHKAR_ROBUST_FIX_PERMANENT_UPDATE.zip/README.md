# My Life V1

Arabic-first Android life operating system built around five pillars:
- Spiritual
- Health
- Personal
- Professional
- Financial

## Core features
- Add, edit, pause, complete, and delete goals from inside each pillar.
- Daily/weekly/monthly/one-time goals.
- XP, levels, streaks, rewards, celebration animations, and animated mountain progress scene.
- Daily dashboard, calendar, statistics, five-pillar balance, rewards.
- Local offline storage.
- JSON backup export/import.
- Android WebView wrapper; no server or Firebase required for V1.

## Build
Open the repository in Android Studio, or run the included GitHub Actions workflow.

Application ID: `com.mylife.app`
Version: `1.0.0`

## V1.1 — Focus Cycle 60/30
- Timer افتراضي: 60 دقيقة تركيز + 30 دقيقة راحة.
- ينتقل تلقائياً بين التركيز والراحة على مدار اليوم.
- اختيار الهدف الحالي من أهداف My Life.
- Pause / Resume / Skip / Reset.
- إحصاء دورات التركيز والراحة ودقائق التركيز اليومية.
- +10 XP لكل ساعة تركيز مكتملة.
- يحفظ حالة التايمر محلياً، ويستمر حساب الوقت بعد التنقل داخل التطبيق.
- يمنع الشاشة من النوم أثناء تشغيل التايمر داخل تطبيق Android.


## V1.2
- صورة شخصية داخل الواجهة.
- تاريخ ووقت مباشر.
- مواقيت الصلاة حسب GPS مع تحديث تلقائي يومي/كل 6 ساعات عبر Aladhan.
- إزالة كل الأهداف الافتراضية؛ يبدأ المستخدم بقائمة فارغة ويضيف/يعدل/يحذف أهدافه بحرية.
- استمرار Focus 60/30.


## V1.3 — Spiritual Suite
- أذكار الصباح والمساء بعداد تفاعلي وحفظ تلقائي يومي.
- القرآن الكريم كامل عبر تحميل السور عند الطلب من AlQuran Cloud، مع حفظ السورة محلياً بعد أول تحميل.
- اختيار السورة وحفظ آخر موضع قراءة.
- ورد يومي قابل للتخصيص بعدد الآيات ومتابعة الإنجاز.
- علامات Bookmark للآيات.
- أهم المعاني والمحاور المختصرة لكل سورة (محتوى توضيحي مختصر وليس بديلاً عن كتب التفسير).
