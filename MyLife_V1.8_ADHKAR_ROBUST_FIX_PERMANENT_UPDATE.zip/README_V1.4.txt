My Life V1.4
- Package path fixed permanently: com.mylife.app
- Permanent release signing key included: app/mylife-release.jks
- Keep this keystore unchanged for ALL future versions.
- Android Back now returns inside the app before exiting.
- Quran reader changed to full Mushaf pages 1-604 with page navigation, daily page wird, bookmark, and cache.
- Morning/evening adhkar expanded substantially.
- Existing goals/data continue in localStorage when updating from another app signed with the SAME permanent key.
IMPORTANT: Previous GitHub debug APKs used ephemeral debug keys. The first switch to V1.4 permanent signing may require uninstalling the old debug app once. After V1.4, future signed releases can update in place.
