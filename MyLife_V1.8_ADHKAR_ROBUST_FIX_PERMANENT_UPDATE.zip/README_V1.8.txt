My Life V1.8
- Fixed blank Adhkar page with static HTML fallback.
- Rebuilt Adhkar navigation and counters using addEventListener.
- WebView cache disabled to ensure updated assets load after APK update.
- Same package: com.mylife.app
- Same permanent release keystore.
- versionCode 9 / versionName 1.8.0
