My Life V1.5
- Permanent applicationId: com.mylife.app
- versionCode 6 / versionName 1.5.0
- Same release keystore as V1.4
- Calendar planner: week/month/year
- Recurring events: weekly/monthly/yearly
- Local Android reminders with notification
- GitHub workflow supports uploading this project as a ZIP
IMPORTANT: Keep repository PRIVATE because the permanent signing key is included for update continuity.
