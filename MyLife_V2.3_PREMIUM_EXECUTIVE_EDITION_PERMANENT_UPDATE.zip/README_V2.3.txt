My Life V2.3 Premium Edition
- Executive-style uncluttered home dashboard
- Focus on today's score, next action, next prayer, key shortcuts, nearest calendar item
- Five life pillars shown as compact horizontal cards
- Full existing features preserved in their dedicated sections
- Daily weight log, target weight, BMI, weekly trend, steps, distance, calories, food equivalent
- Quran, adhkar, prayer times, focus timer, calendar history, reminders, backups, XP/streaks
- Permanent package/signing line preserved: com.mylife.app
- versionCode 14 / versionName 2.3.0
