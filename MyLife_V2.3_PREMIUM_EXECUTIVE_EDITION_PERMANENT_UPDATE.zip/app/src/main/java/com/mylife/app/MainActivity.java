package com.mylife.app;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.Manifest;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.WindowManager;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity implements SensorEventListener {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 42;
    private static final int REQ_LOCATION = 73;
    private static final int REQ_NOTIFICATIONS = 74;
    private static final int REQ_ACTIVITY = 75;

    private SensorManager sensorManager;
    private Sensor stepCounterSensor;
    private SharedPreferences stepPrefs;
    private long todaySteps = 0L;
    private boolean stepSupported = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setGeolocationEnabled(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);

        webView.clearCache(true);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                boolean granted = Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                        checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
                callback.invoke(origin, granted, false);
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;
                Intent intent = fileChooserParams.createIntent();
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (Exception e) {
                    MainActivity.this.filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
        }

        createReminderChannel();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }

        setupStepCounter();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
                checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACTIVITY_RECOGNITION}, REQ_ACTIVITY);
        }

        webView.loadUrl("file:///android_asset/index.html");
    }

    private void setupStepCounter() {
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        stepPrefs = getSharedPreferences("mylife_steps", MODE_PRIVATE);
        if (sensorManager != null) {
            stepCounterSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
            stepSupported = stepCounterSensor != null;
        }
    }

    private boolean hasActivityPermission() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.Q ||
                checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED;
    }

    private String todayKey() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (stepSupported && hasActivityPermission() && sensorManager != null && stepCounterSensor != null) {
            sensorManager.registerListener(this, stepCounterSensor, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (sensorManager != null) sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() != Sensor.TYPE_STEP_COUNTER) return;
        long total = (long) event.values[0];
        String today = todayKey();
        String savedDate = stepPrefs.getString("date", "");
        long baseline = stepPrefs.getLong("baseline", -1L);
        long carried = stepPrefs.getLong("carried", 0L);
        long lastSensor = stepPrefs.getLong("last_sensor", -1L);

        if (!today.equals(savedDate)) {
            // New day. Use the last seen sensor value as the best available midnight baseline.
            baseline = (lastSensor >= 0 && total >= lastSensor) ? lastSensor : total;
            carried = 0L;
            savedDate = today;
        } else if (baseline < 0) {
            baseline = total;
        }

        // Sensor total can reset after reboot. Preserve the already counted part of the day.
        if (lastSensor >= 0 && total < lastSensor) {
            carried += Math.max(0L, lastSensor - baseline);
            baseline = total;
        }

        todaySteps = Math.max(0L, carried + (total - baseline));
        stepPrefs.edit()
                .putString("date", savedDate)
                .putLong("baseline", baseline)
                .putLong("carried", carried)
                .putLong("last_sensor", total)
                .putLong("today_steps", todaySteps)
                .apply();

        if (webView != null) {
            webView.post(() -> webView.evaluateJavascript(
                    "if(window.refreshActivityUI){window.refreshActivityUI();}", null));
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    private void createReminderChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("mylife_reminders", "My Life Reminders", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("تذكيرات الأهداف والمواعيد");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                Uri uri = data.getData();
                if (uri != null) results = new Uri[]{uri};
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        webView.evaluateJavascript("(window.myLifeBack ? window.myLifeBack() : false)", value -> {
            if ("false".equals(value) || "null".equals(value)) {
                MainActivity.super.onBackPressed();
            }
        });
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void saveBackup(String json) {
            runOnUiThread(() -> {
                try {
                    String fileName = "MyLife_Backup_" + System.currentTimeMillis() + ".json";
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                    values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                    values.put(MediaStore.Downloads.RELATIVE_PATH, "Download/MyLife");
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri != null) {
                        try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                            if (os != null) os.write(json.getBytes(StandardCharsets.UTF_8));
                        }
                        Toast.makeText(MainActivity.this, "تم حفظ النسخة الاحتياطية في Downloads/MyLife", Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "تعذر حفظ النسخة الاحتياطية", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void refreshStepCounter() {
            runOnUiThread(() -> {
                if (stepSupported && hasActivityPermission() && sensorManager != null && stepCounterSensor != null) {
                    sensorManager.unregisterListener(MainActivity.this);
                    sensorManager.registerListener(MainActivity.this, stepCounterSensor, SensorManager.SENSOR_DELAY_FASTEST);
                    webView.postDelayed(() -> {
                        if (sensorManager != null) {
                            sensorManager.unregisterListener(MainActivity.this);
                            sensorManager.registerListener(MainActivity.this, stepCounterSensor, SensorManager.SENSOR_DELAY_NORMAL);
                        }
                    }, 700);
                }
            });
        }

        @JavascriptInterface
        public String getStepData() {
            try {
                JSONObject j = new JSONObject();
                j.put("supported", stepSupported);
                j.put("permission", hasActivityPermission());
                long saved = stepPrefs != null ? stepPrefs.getLong("today_steps", todaySteps) : todaySteps;
                j.put("steps", saved);
                j.put("date", todayKey());
                return j.toString();
            } catch (Exception e) {
                return "{\"supported\":false,\"permission\":false,\"steps\":0}";
            }
        }

        @JavascriptInterface
        public void toast(String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
        }

        @JavascriptInterface
        public void scheduleReminder(String id, String title, long atMillis, String repeat) {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(MainActivity.this, ReminderReceiver.class);
                    intent.putExtra("id", id);
                    intent.putExtra("title", title);
                    intent.putExtra("repeat", repeat);
                    intent.putExtra("atMillis", atMillis);
                    int requestCode = id.hashCode();
                    PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                    AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                    if (am != null) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, Math.max(System.currentTimeMillis()+1000, atMillis), pi);
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void cancelReminder(String id) {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(MainActivity.this, ReminderReceiver.class);
                    PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, id.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                    AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                    if (am != null) am.cancel(pi);
                    pi.cancel();
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void setKeepScreenOn(boolean enabled) {
            runOnUiThread(() -> {
                if (enabled) {
                    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                } else {
                    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                }
            });
        }
    }
}
