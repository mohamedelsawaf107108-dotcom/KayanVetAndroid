My Life V2.1

New health/weight tracking:
- User-defined target weight
- Weight history saved by date
- Weekly weight chart (last recorded value per week)
- Progress percentage toward target
- Remaining kilograms to target
- Start weight and total change
- Keeps V2.0 step counter, distance, calories, food equivalents
- Same applicationId com.mylife.app
- Same permanent release keystore
- versionCode 12, versionName 2.1.0
