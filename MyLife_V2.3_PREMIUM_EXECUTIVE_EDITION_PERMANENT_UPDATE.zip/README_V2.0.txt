My Life V2.0
- Fixed weight/height editing using an in-app form with explicit Save.
- Shows healthy BMI weight range, midpoint target, current BMI and difference from target.
- Step refresh now asks the Android sensor for a fresh reading and shows last-read time.
- Same applicationId com.mylife.app and same permanent release keystore.
- versionCode 11 / versionName 2.0.0
